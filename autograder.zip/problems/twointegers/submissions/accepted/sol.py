#!/usr/bin/python3
a = int(input())
b = int(input())
print(a, b)
