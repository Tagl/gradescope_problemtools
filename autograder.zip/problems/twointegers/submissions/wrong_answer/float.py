#!/usr/bin/python3
a = float(input())
b = float(input())
print(a, b)
