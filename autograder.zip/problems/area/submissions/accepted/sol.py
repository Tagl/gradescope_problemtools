#!/usr/bin/python3
a = float(input())
b = float(input())
answer = a*b
print("{:.4f}".format(answer))
