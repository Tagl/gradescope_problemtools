#!/usr/bin/python3
a = float(input())
b = float(input())
print("{:.4f}".format(round(a*b)))
